"use strict";
class produkt {
    constructor(ean, nazwa, kategoria, sektor, regal, polka) {
        this.ean = ean;
        this.nazwa = nazwa;
        this.kategoria = kategoria;
        this.sektor = sektor;
        this.regal = regal;
        this.polka = polka;
    }
}
const lista = [
    new produkt("1234567890", "laptop", "urzadzenia", "A", "1", "2"),
    new produkt("0987654321", "telefon", "urzadzenia", "B", "3", "1"),
    new produkt("1234509876", "glosnik", "urzadzenia", "C", "2", "4"),
    new produkt("0987612345", "sluchawki", "urzadzenia", "A", "2", "1")
];
const szukaj = document.getElementById("szukaj");
const produkty = document.getElementById("produkty");
const licznik = document.getElementById("licznik");
function pokaz(dane) {
    produkty.innerHTML = "";
    dane.forEach(p => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${p.ean}</td>
            <td>${p.nazwa}</td>
            <td>${p.kategoria}</td>
            <td>${p.sektor}</td>
            <td>${p.regal}</td>
            <td>${p.polka}</td>
        `;
        produkty.appendChild(tr);
    });
    licznik.innerText = "liczba produktow: " + dane.length;
}
szukaj.addEventListener("input", () => {
    const fraza = szukaj.value.toLowerCase().trim();
    if (fraza === "") {
        pokaz(lista);
    }
    else {
        const wynik = lista.filter(x => x.ean.toLowerCase().includes(fraza) || x.nazwa.toLowerCase().includes(fraza));
        pokaz(wynik);
    }
});
pokaz(lista);
